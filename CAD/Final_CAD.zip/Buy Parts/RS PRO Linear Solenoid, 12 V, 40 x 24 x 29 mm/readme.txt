Name                     Data sheet csv file description of MISUMI web site

Overview                 To be able to import MISUMI product information to the database

Description              Misumi provides the product information by csv file. The customer can import it to the customers database.

Demo

Date Created             Data create date_yyyymmdd_hhmmss                                                                                             e.g. 20160720_22440
Part Number              Part number                                                                                                                  e.g. SFJ3-10
Category_Number          MISUMI web catalogue category number                                                                                         e.g. M0101000000
Category                 Product category name                                                                                                        e.g. Linear Shafts
Title                    Product name                                                                                                                 e.g. Linear Shaft - Straight
Price_Currency           Price currency                                                                                                               e.g. EUR
Min_Quantity             Minimum quantity of order                                                                                                    e.g. 10
Order_Unit               Minimum unit of order                                                                                                        e.g. 5
Standard_Price1          Unit price of 1st slot minimum quantity of order                                                                             e.g. 2.14
Quantity_Price1          1st slot minimum quantity of order                                                                                           e.g. 2
Shippingdays_Price1      Shipping date for the 1st slot minimum quantity of order                                                                     e.g. 7
Standard_Price2          2nd slot price of volume discount table                                                                                      e.g. 2.03
Quantity_Price2          2nd slot quantity of volume discount table(from C to D)                                                                      e.g. 5_12
Standard_Price3          3rd slot price of volume discount table                                                                                      e.g. 1.57
Quantity_Price3          3rd slot quantity of volume discount table(from E to F)                                                                      e.g. 13_19
Standard_Price4          4th slot price of volume discount table                                                                                      e.g. 1.28
Quantity_Price4          4th slot quantity of volume discount table(from G to H)                                                                      e.g. 20_49
Standard_Price5          5th slot price of volume discount table                                                                                      e.g. 0.92
Quantity_Price5          5th slot quantity of volume discount table(from I to J)                                                                      e.g. 50_300
Standard_Price6          6th slot price of volume discount table                                                                                      e.g. 0.92
Quantity_Price6          6th slot quantity of volume discount table(from K to L)                                                                      e.g. 301_
                                                                                                                                                      *over 301 pcs
Standard_Price7          7th slot price of volume discount table
Quantity_Price7          7th slot quantity of volume discount table(from M to N)
Standard_Price8          8th slot price of volume discount table
Quantity_Price8          8th slot quantity of volume discount table(from O to P)
Standard_Price9          9th slot price of volume discount table
Quantity_Price9          9th slot quantity of volume discount table(from Q to R)
Standard_Price10         10th slot price of volume discount table
Quantity_Price10         10th slot quantity of volume discount table(from S to T)
Price_Expiration         Quotation expiration_yyyymmdd_hhmmss                                                                                         e.g. 20160720_224400
Specificationtitle N     Specification titles are as follows                                                                                          e.g. Basic Shape
Specification N          Specifications are as follows                                                                                                e.g. Straight
